<!-- Footer -->
<footer class="sticky-footer bg-white">
<div class="container my-auto">
  <div class="copyright text-center my-auto">
    <span>Copyright &copy; 2019 <a href="https://startbootstrap.com/themes/sb-admin-2/" target="_blank"> SB Admin 2</a></span>
  </div>
</div>
</footer>
<!-- End of Footer -->